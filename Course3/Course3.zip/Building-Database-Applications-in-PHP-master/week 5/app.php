<!DOCTYPE html>
<html>
<head>
<title>Ambika Patidar's - Autompbiles Database</title>
<?php require_once "bootstrap.php"; ?>
</head>
<body>
<div class="container">
<h1>Ambika Patidar's Automobiles Database</h1>
<p>
<a href="login.php">Please log in</a>
</p>
<p>
Attempt to
<a href="add.php">add.php</a> without logging in
</p>
</div>
</body>
</html>
